# TPS Street Soccer Telegram Bot

## Render settings
- Build command: `pip install -r requirements.txt`
- Start command: `python bot.py`
- Environment variable: `BOT_TOKEN` = token of the NEW Telegram bot
- Optional: `ADMIN_ID` = Telegram numeric ID of the main admin (defaults to the ID configured in the source)

## First setup
1. Start the bot in private chat and complete Roblox username registration.
2. Add the bot to the admin group and give it permission to send messages.
3. As the main admin, send `/setgroup` in that group.
4. Give the bot permission to post in the TM channel.
5. In private chat send `/setchannel @your_channel`.

The database is created automatically as `tps_street_soccer.db`.
